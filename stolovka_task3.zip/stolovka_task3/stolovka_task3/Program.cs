using System.Reflection;
using BusinessLogic.Interfaces;
using BusinessLogic.Services;
using DataAccess.Models;
using DataAccess.Wrapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;

namespace BackendApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddDbContext<StolovkaContext>(
                options => options.UseSqlServer(
                    connectionString: "Server=DESKTOP-KUNNO5V\\SQLEXPRESS;Database=stolovka;Trusted_Connection=True;TrustServerCertificate=True;"));

            builder.Services.AddScoped<IRepositoryWrapper, RepositoryWrapper>();
            builder.Services.AddScoped<IStudentService, StudentService>();
        }
    }
}
