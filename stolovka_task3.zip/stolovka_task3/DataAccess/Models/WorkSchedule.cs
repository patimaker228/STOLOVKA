﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class WorkSchedule
{
    public int ScheduleId { get; set; }

    public int StaffId { get; set; }

    public DateOnly WorkDate { get; set; }

    public TimeOnly? StartTime { get; set; }

    public TimeOnly? EndTime { get; set; }

    public virtual Staff Staff { get; set; } = null!;
}
