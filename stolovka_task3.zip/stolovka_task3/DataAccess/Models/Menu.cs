﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class Menu
{
    public int DishId { get; set; }

    public string DishName { get; set; } = null!;

    public int CategoryId { get; set; }

    public decimal Price { get; set; }

    public string? Description { get; set; }

    public virtual Category Category { get; set; } = null!;

    public virtual ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>();
}
