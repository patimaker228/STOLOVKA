﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class Warehouse
{
    public int IngredientId { get; set; }

    public int SupplierId { get; set; }

    public DateOnly? LastDeliveryDate { get; set; }

    public decimal CurrentQuantity { get; set; }

    public virtual Ingredient Ingredient { get; set; } = null!;

    public virtual Supplier Supplier { get; set; } = null!;
}
