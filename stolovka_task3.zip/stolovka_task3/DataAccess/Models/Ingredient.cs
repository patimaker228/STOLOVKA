﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class Ingredient
{
    public int IngredientId { get; set; }

    public string IngredientName { get; set; } = null!;

    public string UnitOfMeasure { get; set; } = null!;

    public virtual Warehouse? Warehouse { get; set; }
}
