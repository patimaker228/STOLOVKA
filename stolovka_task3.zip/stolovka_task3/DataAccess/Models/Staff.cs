﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models;

public partial class Staff
{
    public int StaffId { get; set; }

    public string LastName { get; set; } = null!;

    public string FirstName { get; set; } = null!;

    public string Position { get; set; } = null!;

    public DateOnly? HireDate { get; set; }

    public string? Phone { get; set; }

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();

    public virtual ICollection<WorkSchedule> WorkSchedules { get; set; } = new List<WorkSchedule>();
}
