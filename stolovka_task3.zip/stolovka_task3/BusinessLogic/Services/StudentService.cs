﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic.Interfaces;
using DataAccess.Models;
using DataAccess.Wrapper;
using Microsoft.EntityFrameworkCore;

namespace BusinessLogic.Services
{
    public class StudentService : IStudentService
    {
        private RepositoryWrapper _repositoryWrapper;

        public StudentService(RepositoryWrapper repositoryWrapper)
        {
            _repositoryWrapper = repositoryWrapper;
        }

        public Task<List<Student>> GetAll()
        {
            return _repositoryWrapper.Student.FindAll().ToListAsync();
        }

        public Task<Student> GetById(int id)
        {
            var student = _repositoryWrapper.Student
                .FindByCondition(x => x.StudentId == id).First();
            return Task.FromResult(student);
        }

        public Task Create(Student model)
        {
            _repositoryWrapper.Student.Create(model);
            _repositoryWrapper.Save();
            return Task.CompletedTask;
        }

        public Task Update(Student model)
        {
            _repositoryWrapper.Student.Update(model);
            _repositoryWrapper.Save();
            return Task.CompletedTask;
        }

        public Task Delete(int id)
        {
            var student = _repositoryWrapper.Student
                .FindByCondition(x => x.StudentId == id).First();

            _repositoryWrapper.Student.Delete(student);
            _repositoryWrapper.Save();
            return Task.CompletedTask;
        }
    }
}