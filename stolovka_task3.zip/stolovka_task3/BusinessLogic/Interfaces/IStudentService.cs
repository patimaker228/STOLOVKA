﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;

namespace BusinessLogic.Interfaces
{
    public interface IStudentService
    {
        
        Task<List<Student>> GetAll();
        
        Task<Student> GetById(int id);
        
        Task Create(Student model);
        
        Task Update(Student model);
        
        Task Delete(int id);
    }
}